package Modelos;

public class Contato {
	
	//Atributos
	private String nome;
	private int numeroCel;
	private Data data;
	
	//Construtores
	public Contato() {}
	
	public Contato(String nome, int numeroCel, int dia, int mes, int ano) {
		setNome(nome);
		setNumeroCel(numeroCel);
		setData(dia,mes,ano);
	}
	
	public Contato(String nome, int numeroCel, String data) {
		setNome(nome);
		setNumeroCel(numeroCel);
		setDataS(data);
	}
	
	//Métodos
	public String getNome() {
		return this.nome;
	}
	
	public int getNumeroCel() {
		return numeroCel;
	}
	
	public String getData() {
		return this.data.formatada();
	}
	
	public Data getDataS() {
		return this.data;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setNumeroCel(int numeroCel) {
		this.numeroCel = numeroCel;
	}
	
	private void setData(int dia, int mes, int ano) {
		this.data = new Data(dia, mes, ano);
	}
	
	private void setDataS(String data) {
		this.data = new Data(data);
	} 

	@Override
	public String toString() {
		return nome + "," + numeroCel + "," + data.getData();
	}
	
}
