package Modelos;

import java.util.*;

import Desafio.Contato;

//import javax.swing.text.html.HTMLDocument.Iterator;

import Modelos.*;

public class ManipuladorDeContatos {
	
	private List <Contato> listaContatos = new ArrayList<>();
	
	private Set<Contato> setContatos = new HashSet<>();
	
	private Map<String, Contato> mapaContatos = new HashMap();
	
	private Contato contato;
	
	
	public void inserir (String nome, String telefone, int dia, int mes) {
		Contato contato = new Contato(nome,telefone,dia,mes);
		mapaContatos.put(contato.getNome(), contato);
		listaContatos.add(contato);
	}

	public void removerContato(String nome) {
		
		Iterator <Contato> i = contatos.iterator();
		
		while (i.hasNext()) {
		
			
			String remover = i.next();
			
			if(nome.equals(setContatos))
			{
				setContatos.remove(i);
			}
		}
		 
		 
	}
	
	public void alterarContato() {
	
	}
	
	public void pesquisarContato () {
		
	}
	
	public void listarTodosContatos () {
		
	}
	
	public void listarComInicial () {
		
	}
	
	public void imprimirNiversMes () {
		
	}
	
	/*public void criaConta(Evento evento) {
		String tipo = evento.getSelecionadoNoRadio("tipo");
		if (tipo.equals("Conta Corrente")) {
			this.conta = new ContaCorrente();
		} else if (tipo.equals("Conta Poupança")) {
			this.conta = new ContaPoupanca();
		}
		this.conta.setAgencia(evento.getString("agencia"));
		this.conta.setNumero(evento.getInt("numero"));
		this.conta.setTitular(evento.getString("titular"));
	}

	public void deposita(Evento evento) {
		double valorDigitado = evento.getDouble("valorOperacao");
		this.conta.deposita(valorDigitado);
	}

	 public void saca(Evento evento) {
	     double valor = evento.getDouble("valorOperacao");
	     this.conta.saca(valor);
	 }
	 
	 public void transfere(Evento evento) {
	     Conta destino = (Conta) evento.getSelecionadoNoCombo("destino");
	     conta.transfere(evento.getDouble("valorTransferencia"), destino);
	 }
	 
	 public void salvaDados (Evento evento) {
		 List<Conta> contas = evento.getLista("listaContas");
		 RepositorioDeContas repositorio = new RepositorioDeContas();
		 repositorio.salva(contas);
	 }
	 
	 public List<Conta> carregaDados () {
		 RepositorioDeContas repositorio = new RepositorioDeContas();
		 return*/ 
}
