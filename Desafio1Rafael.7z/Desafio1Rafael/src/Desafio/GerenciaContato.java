package Desafio;
import java.util.*;
import java.io.*;

public class GerenciaContato {
	
	private Map<String,Contato> contatos = new HashMap();
	private List<Contato> contatosLista = new ArrayList<>();
	private File escrita;
	private File leitura;
	
	public void addContato(String nome, String telefone, int dia, int mes) {
		Contato c = new Contato(nome,telefone,dia,mes);
		contatos.put(c.getNome(), c);
		contatosLista.add(c);
	}
	
	public Contato pesquisaContato(String nome){
		if (contatos.containsKey(nome)) {
			Contato c = contatos.get(nome);
			return c;
		}
		return null;
	}
	
	public String removeContato(String nome) {	
		Contato c = pesquisaContato(nome);
		
		if (c==null) {
			return "Contato inválido";
		}else {
			contatosLista.remove(c);
			contatos.remove(c);
			return "Contato removido";
		}
	}
	
	public List<Contato> getLista() {
		return contatosLista;
	}

	public void listaContatos() {
		System.out.println(contatosLista);
	}
	
	public void setArquivoEscrita(File file) {
		this.escrita = file;
	}
	
	public void setArquivoLeitura(File file) {
		this.leitura = file;
	}
	
	public void gravaContatos() {
		PrintStream stream;
		try {
			stream = new PrintStream(escrita);
			for (Contato c : contatosLista) {
				stream.println(c);
			}
			stream.close();
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void carregaContatos() {
		Scanner s;
		String[] dados;
		Contato c;
		
		try{
			s = new Scanner(leitura);
			contatosLista = new ArrayList<>();
			contatos = new HashMap();
			
			while(s.hasNextLine()) {
				dados = s.nextLine().split(",");
				c = new Contato(dados[0],dados[1],dados[2]);
				contatosLista.add(c);
				contatos.put(dados[0],c);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("nao achou o arquivo");
			e.printStackTrace();
		}
	}
}
	
	
