package Desafio;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.AbstractTableModel;

public class InterfaceGrafica {
	
	private JPanel painelPrincipal = new JPanel();
	private JFrame janelaPrincipal = new JFrame("Agenda");
	private JPanel painelAdicionar = new JPanel(new BorderLayout());
	private JFrame janelaAdicionar = new JFrame("Adicionar Contato");
	private JFrame janelaListar = new JFrame();
	private JPanel painelListar = new JPanel(new BorderLayout());
	private JFrame janelaPesquisar = new JFrame("Pesquisar");
	private JPanel painelPesquisar = new JPanel();
	
	private JFileChooser fileChooser = new JFileChooser();
	
	private JButton botaoAdicionar = new JButton("Adicionar Contato");
	private JButton botaoListar = new JButton("Listar Contatos");
	private JButton botaoPesquisar = new JButton("Pesquisar Contato");
	private JButton botaoRemover = new JButton("Remover Contato");
	private JButton botaoArquivoLeitura = new JButton("Escolher arquivo para carregar contatos");
	private JButton botaoLeitura = new JButton("Carregar Contatos");
	private JButton botaoArquivoEscrita = new JButton("Escolher arquivo para guardar contatos");
	private JButton botaoEscrita = new JButton("Guardar Contatos");
	private JButton botaoSair = new JButton("Sair");
	
	public GerenciaContato agenda = new GerenciaContato();
	
	
	public InterfaceGrafica() {
		montarJanelaPrincipal();
		montarJanelaAdicionar();
	}
	
	public void montarJanelaPrincipal() {

		painelPrincipal.add(botaoAdicionar);
		painelPrincipal.add(botaoListar);
		painelPrincipal.add(botaoPesquisar);
		painelPrincipal.add(botaoRemover);
		painelPrincipal.add(botaoArquivoLeitura);
		painelPrincipal.add(botaoLeitura);
		painelPrincipal.add(botaoArquivoEscrita);
		painelPrincipal.add(botaoEscrita);
		painelPrincipal.add(botaoSair);
		
		
		montaBotoes();
		
		
		janelaPrincipal.add(painelPrincipal);
		janelaPrincipal.setLocationRelativeTo(null);
		janelaPrincipal.setSize(540, 540);
		janelaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void montarJanelaAdicionar() {
		
		JPanel painelNome = new JPanel();
		JPanel painelTelefone = new JPanel();
		JPanel painelData = new JPanel();
		JPanel painelNorte = new JPanel(new BorderLayout());
		
//		painelNome.setBorder(BorderFactory.createEmptyBorder(50,200,10,200));
//		painelTelefone.setBorder(BorderFactory.createEmptyBorder(50,180,50,180));
//		painelData.setBorder(BorderFactory.createEmptyBorder(0,100,10,100));
		
		painelAdicionar.setBorder(BorderFactory.createEmptyBorder(0,0,300,0));
		
		JLabel nomeLabel = new JLabel("nome");
		JLabel telefoneLabel = new JLabel("telefone");
		JLabel dataLabel = new JLabel("Data de Nascimento");
		
		JTextField nomeField = new JTextField(05);
		JTextField telefoneField = new JTextField(07);
		JTextField diaField = new JTextField(02);
		JTextField mesField = new JTextField(02);
		
		JButton add = new JButton("Adicionar");
		add.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String n = nomeField.getText();
				String t = telefoneField.getText();
				String d = diaField.getText();
				String m = mesField.getText();
				
				agenda.addContato(n, t, Integer.parseInt(d), Integer.parseInt(m));
				janelaAdicionar.setVisible(false);
				janelaPrincipal.setVisible(true);
			}
		});
		
		painelNome.add(nomeLabel, BorderLayout.WEST);
		painelNome.add(nomeField, BorderLayout.EAST);
		painelTelefone.add(telefoneLabel, BorderLayout.WEST);
		painelTelefone.add(telefoneField, BorderLayout.EAST);
		painelData.add(dataLabel);
		painelData.add(diaField);
		painelData.add(mesField);
		painelNorte.add(painelNome, BorderLayout.NORTH);
		painelNorte.add(painelTelefone,BorderLayout.CENTER);
		painelNorte.add(painelData,BorderLayout.SOUTH);
		painelAdicionar.add(painelNorte,BorderLayout.NORTH);
		painelAdicionar.add(add,BorderLayout.SOUTH);
		
//		janelaAdicionar.add(painelNome);
//		janelaAdicionar.add(painelTelefone);
		janelaAdicionar.add(painelAdicionar);
		janelaAdicionar.setSize(540, 540);
		janelaAdicionar.setLocationRelativeTo(null);
		janelaAdicionar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void mostrarJanelaPrincipal() {
		janelaPrincipal.setVisible(true);
	}
	
	public void mostrarJanelaAdicionar() {
		janelaPrincipal.setVisible(false);
		janelaAdicionar.setVisible(true);
	}
	
	public void mostrarJanelaListar() {
		JTable tabela = new JTable();
		tabela.setBorder(new LineBorder(Color.black));
		tabela.setGridColor(Color.black);
		tabela.setShowGrid(true);
		tabela.setModel(new contatosModelo(agenda.getLista()));
		JScrollPane scroll = new JScrollPane(); 
		scroll.getViewport().setBorder(null);
		scroll.getViewport().add(tabela); 
		scroll.setSize(450, 450);
		
		
		
		JButton cancelar = new JButton("Cancelar");
		cancelar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				janelaListar.setVisible(false);
				janelaPrincipal.setVisible(true);
			}
		});
		
		painelListar.add(tabela,BorderLayout.NORTH);
		painelListar.add(cancelar,BorderLayout.SOUTH);
		
		janelaListar.setSize(540,540);
		janelaListar.setLocationRelativeTo(null);
		janelaListar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janelaListar.add(painelListar);
		
		
		janelaPrincipal.setVisible(false);
		janelaListar.setVisible(true);
		
	}
	
	public void mostrarJanelaPesquisar() {
		
		
		
		
	}
	
	public void montaBotoes() {
		botaoSair.addActionListener(sairListener);
		botaoAdicionar.addActionListener(adicionarListener);
		botaoListar.addActionListener(listarListener);
		botaoArquivoLeitura.addActionListener(arquivoLeituraListener);
		//botaoArquivoEscrita.addActionListener(arquivoEscritaListener);
		
		botaoArquivoEscrita.addActionListener(new ActionListener ( ) {
			 
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                      File file = fileChooser.getSelectedFile();
                      //agenda.setArquivoLeitura(file);
                      return;
                      // faz alguma coisa com arquivo
                    } else {
                      // dialogo cancelado
                }
            }
           
        });
		
		botaoLeitura.addActionListener(LeituraListener);
		botaoEscrita.addActionListener(EscritaListener);
	}
	
	
	
	
	
	//Listeners dos botoes 
	
	
	ActionListener sairListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
		    System.exit(0);			
		}
	};
	ActionListener adicionarListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			mostrarJanelaAdicionar();
		}
	};
	
	ActionListener listarListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			mostrarJanelaListar();
		}
	};
	
	ActionListener arquivoLeituraListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
				  File file = fileChooser.getSelectedFile();
				  agenda.setArquivoLeitura(file);
				  return;
				  // faz alguma coisa com arquivo
				} else {
				  // dialogo cancelado
			}
		}
	};
	
	ActionListener arquivoEscritaListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
			int retorno = fileChooser.showOpenDialog(null);
			if (retorno == JFileChooser.APPROVE_OPTION) {
				  File file = fileChooser.getSelectedFile();
				  agenda.setArquivoEscrita(file); 
				  // faz alguma coisa com arquivo
				} else {
				  // dialogo cancelado
				}
		}
	};
	
	ActionListener LeituraListener = new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
				  agenda.carregaContatos();

		}
		
	};
	
	ActionListener EscritaListener = new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
				  agenda.gravaContatos();

		}
		
	};

	ActionListener PesquisarListener = new ActionListener() {
		
		public void actionPerformed (ActionEvent arg0) {
			mostrarJanelaPesquisar();
		}
	};
	
	
	//Tabela para listar os contatos:
	
	class contatosModelo extends AbstractTableModel {
		 
		   private final List<Contato> contatos;
		 
		   public contatosModelo(List<Contato> contatos) {
		     this.contatos = contatos;
		   }
		 
		   @Override
		   public int getColumnCount() {
		     return 3;
		   }
		 
		   @Override
		   public int getRowCount() {
		     return contatos.size();
		   }
		 
		   @Override
		   public Object getValueAt(int rowIndex, int columnIndex) {
		     Contato c = contatos.get(rowIndex);
		     
		     switch (columnIndex) {
		     case 0:
		       return c.getNome();
		     case 1:
		       return c.getTelefone();
		     case 2:
		       return c.getData();
		     }
		     return null;
		   }
	}
	
}
