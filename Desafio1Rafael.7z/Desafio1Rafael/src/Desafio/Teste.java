package Desafio;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceGrafica ig = new InterfaceGrafica();
		ig.montarJanelaPrincipal();
		ig.mostrarJanelaPrincipal();
	}

}
