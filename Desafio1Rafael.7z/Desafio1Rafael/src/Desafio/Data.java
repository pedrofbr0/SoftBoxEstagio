package Desafio;

public class Data {
	
	String data;
	
	public Data() {}
	
	public Data(int dia, int mes) {
		setData(dia,mes);
	}
	
	public Data (String data) {
		this.data = data;
	}
	
	public void setData (int dia, int mes) {
		if (dia > 28 && mes == 2) {
			data = "Data invalida";
		}else if (dia >30 && (mes == 4 || mes == 6 || mes == 9 || mes == 11)) {
			data = "Data invalida";
		}else if (dia>31) {
			data = "Data invalida";
		}else {
			data = dia+"/"+mes;
		}
	}
	
	public String getData() {				
		return data;
	}
}
