package Interfaces;

import Desafio.*;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class TelaAdicionar {
	
	private JPanel painelAdicionar = new JPanel(new BorderLayout());
	private JFrame janelaAdicionar = new JFrame("Adicionar Contato");
	Contato c;

	public void montarJanelaAdicionar() {
			
			JPanel painelNome = new JPanel();
			JPanel painelTelefone = new JPanel();
			JPanel painelData = new JPanel();
			JPanel painelNorte = new JPanel(new BorderLayout());
			
	//		painelNome.setBorder(BorderFactory.createEmptyBorder(50,200,10,200));
	//		painelTelefone.setBorder(BorderFactory.createEmptyBorder(50,180,50,180));
	//		painelData.setBorder(BorderFactory.createEmptyBorder(0,100,10,100));
			
			painelAdicionar.setBorder(BorderFactory.createEmptyBorder(0,0,300,0));
			
			JLabel nomeLabel = new JLabel("nome");
			JLabel telefoneLabel = new JLabel("telefone");
			JLabel dataLabel = new JLabel("Data de Nascimento");
			
			JTextField nomeField = new JTextField(05);
			JTextField telefoneField = new JTextField(07);
			JTextField diaField = new JTextField(02);
			JTextField mesField = new JTextField(02);
			
			JButton add = new JButton("Adicionar");
			add.addActionListener(new ActionListener() {
	
				@Override
				public void actionPerformed(ActionEvent e) {
					String n = nomeField.getText();
					String t = telefoneField.getText();
					String d = diaField.getText();
					String m = mesField.getText();
					
					addContato(n,t,Integer.parseInt(d),Integer.parseInt(m));
					System.exit(0);
	
				}
			});
			
			painelNome.add(nomeLabel, BorderLayout.WEST);
			painelNome.add(nomeField, BorderLayout.EAST);
			painelTelefone.add(telefoneLabel, BorderLayout.WEST);
			painelTelefone.add(telefoneField, BorderLayout.EAST);
			painelData.add(dataLabel);
			painelData.add(diaField);
			painelData.add(mesField);
			painelNorte.add(painelNome, BorderLayout.NORTH);
			painelNorte.add(painelTelefone,BorderLayout.CENTER);
			painelNorte.add(painelData,BorderLayout.SOUTH);
			painelAdicionar.add(painelNorte,BorderLayout.NORTH);
			painelAdicionar.add(add,BorderLayout.SOUTH);
			
	//		janelaAdicionar.add(painelNome);
	//		janelaAdicionar.add(painelTelefone);
			janelaAdicionar.add(painelAdicionar);
			janelaAdicionar.setSize(540, 540);
			janelaAdicionar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public Contato addContato(String nome, String telefone, int dia, int mes) {
		Contato c = new Contato(nome,telefone,dia,mes);
		return c;
		
	}
		
	public void mostrarJanelaAdicionar() {
		janelaAdicionar.setVisible(true);
	}
	
	public void esconderJanelaAdicionar() {
		janelaAdicionar.setVisible(false);
	}
		
	
}
