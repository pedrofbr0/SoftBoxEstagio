package Telas;

import java.awt.event.*;
import java.io.File;

import javax.swing.*; 



public class TestaTelaAgenda {  
	
	public static void main(String[] args) {  
	
		JButton adicionar = new JButton("Adicionar");//creating instance of JButton  
		//adicionar.setBounds(20,50,100, 40);//x axis, y axis, width, height
		
		JButton remover = new JButton("Remover");//creating instance of JButton  
		//remover.setBounds(20,100,100, 40);//x axis, y axis, width, height  
		
		JButton editar = new JButton("Editar");//creating instance of JButton  
		//editar.setBounds(20,150,100, 40);//x axis, y axis, width, height  
		
		JButton pesquisar = new JButton("Pesquisar");//creating instance of JButton  
		//pesquisar.setBounds(20,200,120, 40);//x axis, y axis, width, height  
		
		JButton listarTodos = new JButton("Listar Todos");//creating instance of JButton  
		//listarTodos.setBounds(20,250,140, 40);//x axis, y axis, width, height  
		
		JButton listarComInicial =new JButton("Listar Pela Inicial");//creating instance of JButton  
		//listarComInicial.setBounds(20,300,180, 40);//x axis, y axis, width, height  
		
		JButton imprimirNiver =new JButton("Aniversariantes do Mês");//creating instance of JButton  
		//imprimirNiver.setBounds(20,350,230, 40);//x axis, y axis, width, height 
		
		JFileChooser fileChooser = new JFileChooser();
		//fileChooser.showOpenDialog(null);
		
		/*JFileChooser fileChooser = new JFileChooser();
		int retorno = fileChooser.showOpenDialog(null);

		if (retorno == JFileChooser.APPROVE_OPTION) {
		  File file = fileChooser.getSelectedFile();
		  // faz alguma coisa com arquivo
		} else {
		  // dialogo cancelado
		}*/
		
		JPanel painel = new JPanel();
		
		painel.add(adicionar);
		painel.add(remover);
		painel.add(editar);
		painel.add(pesquisar);
		painel.add(listarTodos);
		painel.add(listarComInicial);
		painel.add(imprimirNiver);
		
		
		JFrame f =new JFrame("Agenda");//creating instance of JFrame  
		
		f.add(painel);
		          
		/*f.add(adicionar);//adding button in JFrame
		f.add(remover);//adding button in JFrame
		f.add(editar);//adding button in JFrame
		f.add(pesquisar);//adding button in JFrame
		f.add(listarTodos);//adding button in JFrame
		f.add(listarComInicial);//adding button in JFrame
		f.add(imprimirNiver);//adding button in JFrame*/
		
		          
		f.setSize(400,500);//400 width and 500 height  
		//f.setLayout(null);//using no layout managers  
		f.setVisible(true);//making the frame visible
		f.pack();
		
		
		
		adicionar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				mostrarTelaAdicionar;
			}
		});
		
		remover.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				mostrarTelaRemover();
			}
		});
		
		editar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				mostrarTelaEditar();
			}
		});
		
		pesquisar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				mostrarTelaEditar();
			}
		});
		
		listarTodos.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				mostrarTelaListaTodos();
			}
		});
		
		listarComInicial.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				mostrarTelaListarComInicial();
			}
		});
		
		imprimirNiver.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				mostrarTelaNiver();
			}
		});
		
	
		}
	}
}