public class Data {
	
	/* Parte 6, 7 e 9 do exercicio */
	
	int dia, mes, ano;
	
	String dataFormatada() {
		String data =  this.dia + "/" + this.mes + "/" + this.ano;
				
		return data;
	}
}
