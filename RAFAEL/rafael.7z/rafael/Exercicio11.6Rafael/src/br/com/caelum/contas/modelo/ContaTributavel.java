package br.com.caelum.contas.modelo;

public interface ContaTributavel extends Conta, Tributavel {

}
