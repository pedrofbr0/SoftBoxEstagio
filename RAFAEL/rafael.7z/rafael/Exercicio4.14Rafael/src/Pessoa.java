public class Pessoa {
	String nome;
	int idade = 0;
	
	void fazAniversario() {
		idade++;
	}
}
