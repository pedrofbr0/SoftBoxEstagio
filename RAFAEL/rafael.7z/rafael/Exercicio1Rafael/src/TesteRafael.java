
public class TesteRafael {
		
			public static void main (String args[]) {
				
				System.out.println("alo");
				
			}
}
