package br.com.caelum.contas.main;
import br.com.caelum.contas.modelo.*;
import br.com.caelum.javafx.api.main.*;

public class Teste {
	
	int x = 37;

	public static void main(String[] args) {
		
		SistemaBancario.mostraTela(false);

		/* 12.12
		 * 
		 * Quando acaba a memória da JVM é lançada a exceção java.lang.OutOfMemoryError,
		 * que imprime o stack trace da JVM.
		 * 
		 */
		
	}

}
