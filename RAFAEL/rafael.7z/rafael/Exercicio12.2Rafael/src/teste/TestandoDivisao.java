package teste;

public class TestandoDivisao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 10239;
		i = i/0;
		System.out.println("Resultado: "+i);
	}

}
