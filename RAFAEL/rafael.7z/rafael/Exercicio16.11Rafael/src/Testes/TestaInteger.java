package Testes;

public class TestaInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer x1 = new Integer(10);
		Integer x2 = new Integer(10);

		if (x1.equals(x2)) {
		    System.out.println("igual");
		} else {
	     System.out.println("diferente");
		}

	}

}
