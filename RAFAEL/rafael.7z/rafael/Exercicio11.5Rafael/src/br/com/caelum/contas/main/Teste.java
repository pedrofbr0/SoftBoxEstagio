package br.com.caelum.contas.main;
import br.com.caelum.contas.modelo.*;
import br.com.caelum.javafx.api.main.*;
import br.com.caelum.contas.*;

public class Teste {
	
	int x = 37;

	public static void main(String[] args) {
		
		SistemaBancario.mostraTela(true);

	}

}
