
public class Usuario {
	
	private String nome;
	private Data data;
	
	public Usuario() {
		
	}
	
	public Usuario(String nome, String data) {
		this.nome = nome;
		Data d = new Data();
		d.setDataSt(data);
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Data getData() {
		return data;
	}
	
	public void setData(Data data) {
		this.data = data;
	}

}
