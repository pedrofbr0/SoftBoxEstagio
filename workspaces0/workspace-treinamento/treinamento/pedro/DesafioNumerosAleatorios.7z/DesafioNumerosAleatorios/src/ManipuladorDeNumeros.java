import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;


public class ManipuladorDeNumeros {

	
	private Integer numero;
	
	private Usuario user;
	private List <Integer> listaNumeros;
	private Set<Integer> grupoNumeros;
	
	private File w;
	private File r;
	
	public ManipuladorDeNumeros(String nome, String data) {
		
		user = new Usuario(nome, data);
		listaNumeros = new ArrayList<>();
		grupoNumeros = new HashSet<>();
	}
	
	public void gerarNumero() {
		
		Random geradorNumero = new Random();
	
		this.numero = geradorNumero.nextInt(89999999)+10000000;	
		
		while(grupoNumeros.contains(this.numero)) {
			this.numero = geradorNumero.nextInt(89999999)+10000000;		
		}
		
		grupoNumeros.add(this.numero);
		listaNumeros.add(this.numero);
		
	}
	
//	public void salvar() {
//		
//		
//		PrintStream st;
//		try {
//			st = new PrintStream(w = new File("lista.txt"));
//			st.println("Nome: " + getNome() + "          Data: " + Usuario.getDataSt());
//			for (Integer numero : listaNumeros) {
//				st.println(numero);
//			}
//			st.close();
//		}catch (FileNotFoundException e) {
//				try {
//					escrita.createNewFile();
//					st = new PrintStream(escrita);
//					for (Contato contato : listaContatos) {
//						st.println(contato);
//					}
//					st.close();
//				} catch (IOException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//			e.printStackTrace();
//	}
//	
//	@Override
//	public String toString() {
//		return "Nome: " + this.getNome() + "Data:       " + this.getDataSt();
//	}
//	

	
}
