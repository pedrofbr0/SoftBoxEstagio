import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.ParseException;

import javax.swing.*;
import javax.swing.text.MaskFormatter;


public class ManipuladorDeTelas {
	
	public void montarTelaPrincipal() {
		
		ManipuladorDeNumeros manipulador;
		
		JFrame telaPrincipal = new JFrame();
		JPanel painelPrincipal = new JPanel();
		
		JTextField nome= new JTextField("Pedro");
		
		JButton ok = new JButton("OK");
		
//		JOptionPane invalida = new JOptionPane("Opa");
		
		MaskFormatter dataFormato = null;
		try {
			dataFormato = new MaskFormatter("##/##/####");
			dataFormato.setValidCharacters("0123456789abcdefABCDEF");

		} catch (ParseException e1) {
			JOptionPane.showMessageDialog(telaPrincipal,"Data Inválida");
//			invalida.createDialog(telaPrincipal, "Data Invália"); 
			e1.printStackTrace();
		}
		
		JFormattedTextField data = new JFormattedTextField(dataFormato);
		data.setText("15/03/2018");
		
		JLabel nomeLabel = new JLabel();
		JLabel dataLabel = new JLabel();
				
		ok.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				
				manipulador = new ManipuladorDeNumeros(nome.getText(), data.getText());
				//Usuario user = new Usuario(nome.getText(), data.getText());
				//montarTelaSecundaria();
				System.out.println("alo");
			}
		});
		
	painelPrincipal.add(nomeLabel);
	painelPrincipal.add(nome);
	painelPrincipal.add(dataLabel);
	painelPrincipal.add(data);
	painelPrincipal.add(ok);
	
	
	telaPrincipal.add(painelPrincipal);
	
	telaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	
	telaPrincipal.pack();
	telaPrincipal.setVisible(true);
	}
	
	public void montarTelaSecundaria() {
		
		
		
		JFrame telaSecundaria = new JFrame();
		JPanel painelSecundario = new JPanel();
		
		JButton gerar = new JButton("Gerar");
		JButton voltar = new JButton("Voltar");
		JButton salvar = new JButton("Salvar");
		JButton visualizar = new JButton("Visualizar Arquivo");
		
		JTextArea numeros = new JTextArea();
		
		JScrollPane scroll = new JScrollPane();
	    scroll.getViewport().add(numeros);
	    scroll.setSize(450, 450);
	    
	    gerar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
			}
		});
	    
	    telaSecundaria.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	    
	    telaSecundaria.pack();
	    telaSecundaria.setVisible(true);
	    
	    
		
		
		
	}
}
