package Telas;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class TelaPrincipal {
	
	public TelaPrincipal() {
		mostrarTelaPrincipal();
		mostrar
	}
	
	private JFrame tela;
	
	private JButton adicionar = new JButton("Adicionar");//creating instance of JButton  
	//adicionar.setBounds(20,50,100, 40);//x axis, y axis, width, height
	
	private JButton remover = new JButton("Remover");//creating instance of JButton  
	//remover.setBounds(20,100,100, 40);//x axis, y axis, width, height  
	
	private JButton editar = new JButton("Editar");//creating instance of JButton  
	//editar.setBounds(20,150,100, 40);//x axis, y axis, width, height  
	
	private JButton pesquisar = new JButton("Pesquisar");//creating instance of JButton  
	//pesquisar.setBounds(20,200,120, 40);//x axis, y axis, width, height  
	
	private JButton listarTodos = new JButton("Listar Todos");//creating instance of JButton  
	//listarTodos.setBounds(20,250,140, 40);//x axis, y axis, width, height  
	
	private JButton listarComInicial =new JButton("Listar Pela Inicial");//creating instance of JButton  
	//listarComInicial.setBounds(20,300,180, 40);//x axis, y axis, width, height  
	
	private JButton imprimirNiver =new JButton("Aniversariantes do Mês");//creating instance of JButton  
	//imprimirNiver.setBounds(20,350,230, 40);//x axis, y axis, width, height 
	
	private JFileChooser fileChooser = new JFileChooser();
	//fileChooser.showOpenDialog(null);
	
	/*JFileChooser fileChooser = new JFileChooser();
	int retorno = fileChooser.showOpenDialog(null);

	if (retorno == JFileChooser.APPROVE_OPTION) {
	  File file = fileChooser.getSelectedFile();
	  // faz alguma coisa com arquivo
	} else {
	  // dialogo cancelado
	}*/
	
	JPanel painel = new JPanel();
	
	painel.add(adicionar);
	painel.add(remover);
	painel.add(editar);
	painel.add(pesquisar);
	painel.add(listarTodos);
	painel.add(listarComInicial);
	painel.add(imprimirNiver);
	
	
	JFrame f =new JFrame("Agenda");//creating instance of JFrame  
	
	f.add(painel);
	          
	/*f.add(adicionar);//adding button in JFrame
	f.add(remover);//adding button in JFrame
	f.add(editar);//adding button in JFrame
	f.add(pesquisar);//adding button in JFrame
	f.add(listarTodos);//adding button in JFrame
	f.add(listarComInicial);//adding button in JFrame
	f.add(imprimirNiver);//adding button in JFrame*/
	
	          
	f.setSize(400,500);//400 width and 500 height  
	//f.setLayout(null);//using no layout managers  
	f.setVisible(true);//making the frame visible
	f.pack();
	
	
public void montarJanelaAdicionar() {
		
		JPanel painelNome = new JPanel();
		JPanel painelTelefone = new JPanel();
		JPanel painelData = new JPanel();
		JPanel painelNorte = new JPanel(new BorderLayout());
		
//		painelNome.setBorder(BorderFactory.createEmptyBorder(50,200,10,200));
//		painelTelefone.setBorder(BorderFactory.createEmptyBorder(50,180,50,180));
//		painelData.setBorder(BorderFactory.createEmptyBorder(0,100,10,100));
		
		painelAdicionar.setBorder(BorderFactory.createEmptyBorder(0,0,300,0));
		
		JLabel nomeLabel = new JLabel("nome");
		JLabel telefoneLabel = new JLabel("telefone");
		JLabel dataLabel = new JLabel("Data de Nascimento");
		
		JTextField nomeField = new JTextField(05);
		JTextField telefoneField = new JTextField(07);
		JTextField diaField = new JTextField(02);
		JTextField mesField = new JTextField(02);
		
		JButton add = new JButton("Adicionar");
		add.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String n = nomeField.getText();
				String t = telefoneField.getText();
				String d = diaField.getText();
				String m = mesField.getText();
				
				agenda.addContato(n, t, Integer.parseInt(d), Integer.parseInt(m));
				janelaAdicionar.setVisible(false);
				janelaPrincipal.setVisible(true);
			}
		});
		
		painelNome.add(nomeLabel, BorderLayout.WEST);
		painelNome.add(nomeField, BorderLayout.EAST);
		painelTelefone.add(telefoneLabel, BorderLayout.WEST);
		painelTelefone.add(telefoneField, BorderLayout.EAST);
		painelData.add(dataLabel);
		painelData.add(diaField);
		painelData.add(mesField);
		painelNorte.add(painelNome, BorderLayout.NORTH);
		painelNorte.add(painelTelefone,BorderLayout.CENTER);
		painelNorte.add(painelData,BorderLayout.SOUTH);
		painelAdicionar.add(painelNorte,BorderLayout.NORTH);
		painelAdicionar.add(add,BorderLayout.SOUTH);
		
//		janelaAdicionar.add(painelNome);
//		janelaAdicionar.add(painelTelefone);
		janelaAdicionar.add(painelAdicionar);
		janelaAdicionar.setSize(540, 540);
		janelaAdicionar.setLocationRelativeTo(null);
		janelaAdicionar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	
	adicionar.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {
			mostrarTelaAdicionar;
		}
	});
	
	remover.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {
			mostrarTelaRemover();
		}
	});
	
	editar.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {
			mostrarTelaEditar();
		}
	});
	
	pesquisar.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {
			mostrarTelaEditar();
		}
	});
	
	listarTodos.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {
			mostrarTelaListaTodos();
		}
	});
	
	listarComInicial.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {
			mostrarTelaListarComInicial();
		}
	});
	
	imprimirNiver.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {
			mostrarTelaNiver();
		}
	});
	
	

}
