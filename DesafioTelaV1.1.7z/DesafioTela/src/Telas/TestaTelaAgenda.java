package Telas;

import java.awt.event.*;
import java.io.File;

import javax.swing.*; 



public class TestaTelaAgenda {  
	
	public static void main(String[] args) {  
	
		Agenda agenda = new Agenda();
		
		agenda.montarTelaPrincipal();
		
		
		
		
		
	
		}
	}
}