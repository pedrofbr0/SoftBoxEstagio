package Telas;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.AbstractTableModel;

import Modelos.Contato;
import Modelos.ManipuladorDeContatos;
import Modelos.*;

public class Agenda {
	
	public Agenda() {
		montarTelaPrincipal();
		montarTelaAdicionar();
		montarTelaListarTodos();
	}
		
		
	
	private JPanel painelPrincipal = new JPanel();
	private JFrame telaPrincipal = new JFrame("Agenda");
	private JPanel painelAdicionar = new JPanel();
	private JFrame telaAdicionar = new JFrame("Adicionar");
	private JPanel painelListarTodos = new JPanel();
	private JFrame telaListarTodos = new JFrame();
	private JPanel painelPesquisar = new JPanel();
	private JFrame telaPesquisar= new JFrame("Pesquisar");
	private JPanel painelRemover = new JPanel();
	private JFrame telaRemover= new JFrame("Remover");
	
	
	private JFileChooser fileChooser = new JFileChooser();

	public ManipuladorDeContatos agenda = new ManipuladorDeContatos();
	
	
	private JButton adicionar = new JButton("Adicionar");
	//adicionar.setBounds(20,50,100, 40);
	
	private JButton remover = new JButton("Remover"); 
	//remover.setBounds(20,100,100, 40);  
	
	private JButton editar = new JButton("Editar");  
	//editar.setBounds(20,150,100, 40);  
	
	private JButton pesquisar = new JButton("Pesquisar");
	//pesquisar.setBounds(20,200,120, 40);
	
	private JButton listarTodos = new JButton("Listar Todos");
	//listarTodos.setBounds(20,250,140, 40);  
	
	private JButton listarComInicial =new JButton("Listar Pela Inicial");  
	//listarComInicial.setBounds(20,300,180, 40);
	
	private JButton imprimirNiver =new JButton("Aniversariantes do Mês");  
	//imprimirNiver.setBounds(20,350,230, 40);
	
	private JButton save = new JButton("Salvar");
	//arquivoSalvar.setBounds(20,350,230, 40); 
	
	private JButton load = new JButton("Load");
	//arquivoLoad.setBounds(20,350,230, 40);
	
	private JButton exit = new JButton("Sair");
	//arquivoLoad.setBounds(20,350,230, 40);
	
	
		
	public void montarTelaPrincipal() {
		
		painelPrincipal.add(adicionar);
		painelPrincipal.add(remover);
		painelPrincipal.add(editar);
		painelPrincipal.add(pesquisar);
		painelPrincipal.add(listarTodos);
		painelPrincipal.add(listarComInicial);
		painelPrincipal.add(imprimirNiver);
		painelPrincipal.add(save);
		painelPrincipal.add(load);
		painelPrincipal.add(exit);	
		
		telaPrincipal.add(painelPrincipal);
		          
		          
		telaPrincipal.setSize(400,500);  
		telaPrincipal.setVisible(true);
		telaPrincipal.pack();
		
		
		//Listeners
		adicionar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				mostrarTelaAdicionar();
			}
		});
		
		remover.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				//mostrarTelaRemover();
			}
		});
		
		editar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				//mostrarTelaEditar();
			}
		});
		
		pesquisar.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				//mostrarTelaPesquisar();
			}
		});
		
		listarTodos.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				//mostrarTelaListaTodos();
			}
		});
		
		listarComInicial.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				//mostrarTelaListarComInicial();
			}
		});
		
		imprimirNiver.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				//mostrarTelaNiver();
			}
		});
		
		save.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				agenda.salva();
			}
		});
		
		load.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				agenda.load();
			}
		});
		exit.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				System.exit(0);
			}
		});
		
		ActionListener arquivoLeituraListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
					
				if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					  File file = fileChooser.getSelectedFile();
					  agenda.setArquivoLeitura(file);
					  return;
						  // faz alguma coisa com arquivo
					} else {
						  // dialogo cancelado
				}
			}
		};
			
		ActionListener arquivoEscritaListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
					
				int retorno = fileChooser.showOpenDialog(null);
				if (retorno == JFileChooser.APPROVE_OPTION) {
					  File file = fileChooser.getSelectedFile();
						 agenda.setArquivoEscrita(file); 
					  // faz alguma coisa com arquivo
					} else {
					  // dialogo cancelado
					}
			}
		};
			
	}
	
	public void montarTelaAdicionar() {
		
		JTextField nome,numeroCel,data;
			
		nome = new JTextField("Exemplo: Rogerinho do Ingá");
		
		numeroCel = new JTextField("Exemplo: +55 34 99119-9331");
		
		data = new JTextField("Exemplo: 01/01");
		
		nome.setBounds(50,50,150,20);  
		
		numeroCel.setBounds(50,150,150,20);  
		
		data.setBounds(50,200,150,20);  
		
		JLabel nomeLabel = new JLabel("Nome");
		JLabel numeroCelLabel = new JLabel("Número");
		JLabel dataLabel = new JLabel("Data de Nascimento");
			
		JButton adicionarContato = new JButton("Adicionar");
		
		adicionarContato.setBounds(50,400,150,20);
		
		adicionarContato.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String n = nome.getText();
				String t = numeroCel.getText();
				String s = data.getText();
				String[] d = null;
				d = s.split("/");	
				agenda.inserir(n, t, Integer.parseInt(d[0]), Integer.parseInt(d[1]));
				
				telaAdicionar.setVisible(false);
				telaPrincipal.setVisible(true);
			}
		
		});
		
	
		painelAdicionar.add(nomeLabel);
		painelAdicionar.add(nome);
		painelAdicionar.add(numeroCelLabel);
		painelAdicionar.add(numeroCel);
		painelAdicionar.add(dataLabel);
		painelAdicionar.add(data);
		painelAdicionar.add(adicionarContato);
		
		telaAdicionar.add(painelAdicionar);
		
		telaAdicionar.setSize(400, 500);
		//telaAdicionar.setVisible(true);
		telaAdicionar.pack();
	}		
	
	public void montarTelaListarTodos() {
		
		JFrame telaLista = new JFrame();
		
		JTable tabela = new JTable();

		JPanel painelLista = new JPanel();
		
		tabela.setModel(new ContatosTabela(agenda.getLista()));
		JScrollPane barra = new JScrollPane(); 
		barra.getViewport().setBorder(null);
		barra.getViewport().add(tabela); 
		barra.setSize(450, 450);
		
		painelListarTodos.removeAll();
        painelListarTodos.add(tabela);
			
		JButton cancelar = new JButton("Voltar");
		
		cancelar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				telaListarTodos.setVisible(false);
				telaPrincipal.setVisible(true);
			}
		});
		
		painelLista.add(cancelar);
		
		telaLista.add(painelLista);
		telaLista.setSize(540,540);
		telaLista.pack();
			
		telaPrincipal.setVisible(false);
		telaLista.setVisible(true);

	}
	
	public void mostrarTelaPrincipal() {
			telaPrincipal.setVisible(true);
	}
			
	public void mostrarTelaAdicionar() {
			telaPrincipal.setVisible(false);
			telaAdicionar.setVisible(true);
	}
		
	public void mostrarTelaRemover( ) {
			telaPrincipal.setVisible(false);
			telaRemover.setVisible(true);
	}
}



