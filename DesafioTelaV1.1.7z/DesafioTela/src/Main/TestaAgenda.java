package Main;

import java.awt.event.*;
import java.util.Scanner;

import javax.swing.*;

import Modelos.ManipuladorDeContatos;
import Telas.Agenda;  

public class TestaAgenda {  
	public static void main(String[] args) {
		
		Agenda agenda = new Agenda();
		
		
		
		
	}  
}  
