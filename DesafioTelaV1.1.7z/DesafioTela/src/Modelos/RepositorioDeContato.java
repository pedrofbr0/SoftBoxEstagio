package Modelos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.*;
import Modelos.*;

public class RepositorioDeContato {
	
	public void salva(List<Contato> contatos) {
		
		PrintStream stream = null;
		
		try {
			stream = new PrintStream("contatos.txt");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		
		for (Contato contato : contatos) {
			stream.println(contato.getNome() + "," + contato.getNumeroCel() + ","
								+ contato.getDataNiver() + ",");
			}
		
		stream.close();
	
	}
	
	public List<Contato> carrega() {
		
		File arquivo = new File("/home/pedro/Documentos/workspaces/workspace-treinamento/treinamento/pedro/Exercicios16.11/contas.txt");
				
		Scanner scanner;
		
		List <Contato> contatos = new ArrayList<>();
		
		Contato contato;
		
		String linha;
		
		String[] valores;
		
		try {
			
			scanner = new Scanner (arquivo);
			
			while (scanner.hasNextLine()) {
				
				linha = scanner.nextLine();
				valores = linha.split(",");
	
				contato = new Contato();
				
				contato.setNome (valores[0]);
				contato.setNumeroCel (Integer.parseInt(valores[1]));
				contato.setDataNiver (Integer.parseInt(valores[2]));
				
				contatos.add (contato);	
					
				scanner.close();
			}
				
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}		    
			
		return contatos;
	}
	
}

