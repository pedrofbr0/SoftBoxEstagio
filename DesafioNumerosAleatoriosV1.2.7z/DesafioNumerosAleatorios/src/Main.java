public class Main {
	
	public static void main(String[] args) {
		
		ManipuladorDeTelas main = new ManipuladorDeTelas();
	
		main.montarTelaPrincipal();
		
	}	
}
